/* Remember to use 'strict' mode in all scripts now! 
You can use strict mode in all your programs. It helps you to write cleaner code, 
like preventing you from using undeclared variables. (https://www.w3schools.com/js/js_strict.asp) */
'use strict';

// Variables for DOM interaction
//*****************************************

const quoteBox = document.getElementById('quote-box"');
const quoteText = document.getElementById('quote');
const authorText = document.getElementById('author');
const twitterBtn = document.getElementById('tweet-quote');
const newQuoteBtn = document.getElementById('new-quote');
const loader = document.getElementById('loader');

// End of Variables for DOM interaction
//*****************************************


// Getting Quotes Section
//*****************************************
//Get Quotes from local API

// Showing the new Quote
function newQuote() {

  // Pick a random quote from localQuotes array
  const quote = localQuotes[Math.floor(Math.random() * localQuotes.length)];
  
  // Verify if author name is blank and replace it whit "Author: unknown";
  if (!quote.author) {
    authorText.textContent = 'Author: unknown';
  } else {
    authorText.textContent = quote.author;
  }
  // Verify Quote length to determine font styling
  if (quote.text.length > 120) {
    quoteText.classList.toggle('long-quote');
  }

  // Set Quote
   quoteText.textContent = quote.text;
  
} 


// For Tweet the current Quote 
function tweetQuote() {
  const twitterUrl = `https://twitter.com/intent/tweet?text=${quoteText.textContent} - ${authorText.textContent}`;
  window.open(twitterUrl, '_blank');
}

// Event Listeners interaction
newQuoteBtn.addEventListener('click', newQuote);
twitterBtn.addEventListener('click', tweetQuote);


// On Loading 
getQuotes();

// End of Getting Quotes Section //
//*****************************************





